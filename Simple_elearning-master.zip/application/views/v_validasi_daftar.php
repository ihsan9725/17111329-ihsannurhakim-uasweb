<!DOCTYPE html>
<html lang="en">

<center><h4>Daftar Berhasil Yeay!!</h4></center>
 <a class="ui inverted button" href="welcome">Beranda</a> 